﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator2
{
    public partial class Form1 : Form
    {
        private string mathop = ""; // gets the nums and math operands 
        private string Equation = ""; // equation 
        private string Result = ""; // final rwsult 

        public Form1()
        {
            InitializeComponent();
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result; 
            textBox1.TextAlign = HorizontalAlignment.Right;

        }

        private void One(object sender, EventArgs e)
        {
            mathop += "1";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }

        private void Two(object sender, EventArgs e)
        {
            mathop += "2";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;

        }

        private void Three(object sender, EventArgs e)
        {
            mathop += "3";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;

        }

        private void Four(object sender, EventArgs e)
        {
            mathop += "4";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;

        }

        private void Five(object sender, EventArgs e)
        {
            mathop += "5";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;


        }

        private void Six(object sender, EventArgs e)
        {
            mathop += "6";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;


        }

        private void Seven(object sender, EventArgs e)
        {
            mathop += "7";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;


        }

        private void Eight(object sender, EventArgs e)
        {
            mathop += "8";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;

        }

        private void Nine(object sender, EventArgs e)
        {
            mathop += "9";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;

        }

        private void PLUS(object sender, EventArgs e)
        {
            mathop += "+";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }

        private void MENOS(object sender, EventArgs e)
        {
            mathop += "-";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }

        private void Multiply(object sender, EventArgs e)
        {
            mathop += "*";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }

        private void Divide(object sender, EventArgs e)
        {
            mathop += "/";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }
        public double Operations(int i, double Num, string number)
        {
            if (i == 0) // multiplicationn
                Num *= Convert.ToDouble(number);
            else if (i == 1) // division 
                Num /= Math.Round(Convert.ToDouble(number), 2);
            else if (i == 2) // modulus 
                Num %= Convert.ToDouble(number);
            else if (i == 3) // add
                Num += Convert.ToDouble(number);
            else // subtract 
                Num -= Convert.ToDouble(number);
            return Num;
        }
        public string newString(double newNum, string left, string right)
        {
            return left + newNum + right;
        }
        public char[] array = new char[] { '*', '/', '%', '+', '-' };
        private void EQUAL(object sender, EventArgs e)
        {
            for (int i = 0; i < array.Length; i++) // check your arrays
            {
                string leftStr = ""; // leftStr will grab the left side 

                string number = ""; // gets the number we want to work with 

                for (int x = 0; x < mathop.Length; x++)
                {
                    string rightStr = ""; // rightStr will grab the right side 
                    if (mathop[x] == array[i] && number != "") 
                    {
                        double Num = Convert.ToDouble(number); 
                        number = ""; 

                        for (int j = x + 1; j < mathop.Length; j++) //next number 
                        {
                            bool negative = false; //check for a negative 

                          
                            if ((mathop[j] == '-' && j == x + 1))
                                negative = true;
                            
                            if ((!Char.IsDigit(mathop[j]) && mathop[j] != '.') && negative == false)
                            {
                                for (int s = j; s < mathop.Length; s++) // stores right part of the string
                                    rightStr += mathop[s];
                                break;
                            }
                            number += mathop[j]; 
                        }

                        Num = Operations(i, Num, number); // method to determine the state of the num 
                        mathop = newString(Num, leftStr, rightStr); // simplify 
                        // reset 
                        x = -1;
                        number = ""; 
                        leftStr = ""; 
                    }

                    else if ((Char.IsDigit(mathop[x]) || mathop[x] == '.') || (x != 0 && (!Char.IsDigit(mathop[x - 1]) && mathop[x] == '-')) || (mathop[x] == '-' && x == 0))
                        number += mathop[x];
                    else
                    {
                        number = ""; 
                        leftStr = "";
                        for (int m = 0; m < x + 1; m++)
                            leftStr += mathop[m];
                    }
                }
            }

            Result = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }

        private void ZERO(object sender, EventArgs e)
        {
            mathop += "0";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Modulo(object sender, EventArgs e)
        {
            mathop += "%";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }

        private void Negative(object sender, EventArgs e)
        {
            mathop += "-";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }

        private void Borrar(object sender, EventArgs e)
        {
            Equation = "";
            Result = "";
            mathop = "";

            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }

        private void Period(object sender, EventArgs e)
        {
            mathop += ".";
            Equation = mathop;
            textBox1.Text = Equation + Environment.NewLine + "--------------------" + Environment.NewLine + Result;
        }
    }
}
